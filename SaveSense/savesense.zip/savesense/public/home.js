// home.js

window.onload = function() {
    const authButtons = document.getElementById('authButtons');
    const logoutSection = document.getElementById('logoutSection');
  
    fetch('/check-session')
      .then(response => response.json())
      .then(data => {
        if (data.loggedIn) {
          authButtons.style.display = 'none';
          logoutSection.style.display = 'block';
        } else {
          authButtons.style.display = 'flex';
          logoutSection.style.display = 'none';
        }
      })
      .catch(error => {
        console.error('Error checking session:', error);
      });
  };
  
  // Logout function
  function logout() {
    fetch('/logout')
      .then(() => {
        window.location.href = '/index.html';
      })
      .catch(error => {
        console.error('Error during logout:', error);
      });
  }
  