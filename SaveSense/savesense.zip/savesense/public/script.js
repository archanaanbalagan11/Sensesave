document.getElementById('searchForm').addEventListener('submit', function(e) {
    e.preventDefault();
  
    const productName = document.getElementById('productInput').value;
    if (!productName) return;
  
    fetch(`/search-product?name=${encodeURIComponent(productName)}`)
      .then(response => response.json())
      .then(data => {
        const priceCards = document.getElementById('priceCards');
        priceCards.innerHTML = ''; // clear previous results
        document.getElementById('resultsSection').style.display = 'block';
  
        if (data.products && data.products.length > 0) {
          data.products.forEach(product => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
              <h3>${product.title}</h3>
              <p><strong>Price:</strong> ₹${product.price ? product.price.current_price : 'Not available'}</p>
              <a href="${product.url}" target="_blank">View Product</a>
            `;
            priceCards.appendChild(card);
          });
        } else {
          priceCards.innerHTML = `<p>No products found.</p>`;
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  });
  