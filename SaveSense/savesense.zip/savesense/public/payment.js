window.onload = function() {
    // Fetch user's financial data when page loads
    fetch('/get-user-finance')
      .then(response => response.json())
      .then(data => {
        document.getElementById('income').value = data.salary;
        document.getElementById('expenses').value = data.expense;
        document.getElementById('loan').value = data.loan;
        document.getElementById('emi').value = data.emi || 0; // if emi is not saved separately
      })
      .catch(error => {
        console.error('Error fetching user data:', error);
      });
  };
  
  function decidePayment() {
    const income = parseFloat(document.getElementById('income').value);
    const expenses = parseFloat(document.getElementById('expenses').value);
    const loan = parseFloat(document.getElementById('loan').value);
    const emi = parseFloat(document.getElementById('emi').value);
    const payment = parseFloat(document.getElementById('payment').value);
  
    const totalMonthlyBurden = expenses + emi + payment;
    const safeLimit = income * 0.5; // assume 50% of income can be spent safely
  
    const resultDiv = document.getElementById('result');
    
    if (totalMonthlyBurden <= safeLimit) {
      resultDiv.innerHTML = "<p style='color: green;'>✅ Payment is feasible within safe limits!</p>";
    } else {
      resultDiv.innerHTML = "<p style='color: red;'>⚠️ Payment may burden your finances. Consider carefully.</p>";
    }
  }
  