const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const session = require("express-session");
const bcrypt = require('bcrypt');
const path = require('path');
const User = require('./userModel');
const axios = require('axios');


const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // To serve HTML/CSS files from /public folder
app.use(session({
  secret: 'a71b07c53f3e5f0a1f9dc1f3d13e5872c7b8c1f45d751963497b6f3d2e4a55ce7de0f3f0d19a44bfcf9b',
  resave: false,
  saveUninitialized: true,
  cookie: { secure: false } // Set secure: true if using HTTPS
}));

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/savesenseDB', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB Connected!'))
  .catch(err => console.log(err));

// Routes

// Signup route
app.post('/signup', async (req, res) => {
  const { name, email, password, salary, loan, expense } = req.body;
  const existingUser = await User.findOne({ email });

  if (existingUser) {
    return res.send('User already exists. Please login.');
  }

  const hashedPassword = await bcrypt.hash(password, 10);

  const newUser = new User({ name, email, password: hashedPassword, salary, loan, expense });
  await newUser.save();

  res.send('Signup successful! <a href="login.html">Login now</a>');
});

// Login route
app.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });

  if (!user) {
    return res.send('User not found. Please signup.');
  }

  const validPassword = await bcrypt.compare(password, user.password);
  
  if (validPassword) {
    req.session.user = {
      name: user.name   // 🔥 Correct here!
    };
    console.log("Session set after login:", req.session);
    return res.redirect('/index.html');
  }
  else {
    return res.send("Wrong password");
  }
});


// Check session route
app.get('/check-session', (req, res) => {
  if (req.session.user) {
    res.json({ loggedIn: true, name: req.session.user.name });
  } else {
    res.json({ loggedIn: false });
  }
});

// Logout route
app.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.log(err);
    }
    res.redirect('/index.html');
  });
});

// Search product route
app.get('/search-product', async (req, res) => {
  const productName = req.query.name;
  
  try {
    const response = await axios.get('https://ecommerce-api3.p.rapidapi.com/femalefootwear ', {
      params: {
        marketplace: 'IN',
        keywords: productName
      },
      headers: {
        'X-RapidAPI-Key': 'a8058f8f6dmsh4d54f5ac97ca6a8p163799jsncdc446a644e0',    // 🔥 Important: Put your key here
        'X-RapidAPI-Host': 'ecommerce-api3.p.rapidapi.com'
      }
    });
    
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).send('Error fetching product data');
  }
});

app.get('/get-user-finance', async (req, res) => {
  if (!req.session.user) {
    return res.status(401).send('Unauthorized');
  }

  try {
    const user = await User.findOne({ name: req.session.user.name });
    if (!user) {
      return res.status(404).send('User not found');
    }

    res.json({
      salary: user.salary,
      expense: user.expense,
      loan: user.loan,
      emi: user.emi || 0  // assuming you have emi saved or default 0
    });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
